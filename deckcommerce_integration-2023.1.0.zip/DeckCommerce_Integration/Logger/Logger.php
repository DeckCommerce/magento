<?php
/**
 * @author DeckCommerce Team
 * @copyright Copyright (c) 2022 DeckCommerce (https://www.deckcommerce.com)
 * @package DeckCommerce_Integration
 */

namespace DeckCommerce\Integration\Logger;

/**
 * Logger model
 */
class Logger extends \Monolog\Logger
{

}
