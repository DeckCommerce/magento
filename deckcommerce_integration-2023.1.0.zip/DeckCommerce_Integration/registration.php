<?php
/**
 * @author DeckCommerce Team
 * @copyright Copyright (c) 2022 DeckCommerce (https://www.deckcommerce.com)
 * @package DeckCommerce_Integration
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'DeckCommerce_Integration',
    __DIR__
);
